import pandas as pd
df = pd.read_csv(filepath_or_buffer="C:\\Users\\HARMEET\\OneDrive\\Desktop\\Airbnb sql.csv",encoding='latin1')
print(df.head())